# Sistema de Gestão de Produtos - CRUD Web

**Trabalho 4** – Aplicação web funcional (CRUD)  
Integrando front-end, camada de controle/regra de negócio e persistência em Banco de Dados.

**Projeto:** crud vander's Project

---

## Objetivo

Desenvolver uma aplicação web completa com as operações **CRUD** (Create, Read, Update, Delete), aplicando o padrão **MVC** e acesso ao banco via **DAO** (equivalente a JDBC).

---

## Arquitetura (MVC + DAO)

```
crud-vander/
├── app.py                 ← Controller (rotas Flask / HTTP)
├── dao/
│   └── produto_dao.py     ← Model / DAO (acesso ao banco)
├── templates/             ← View (HTML)
│   ├── base.html
│   ├── index.html
│   ├── form.html
│   └── detalhe.html
├── database.sql           ← Script SQL (PostgreSQL)
├── produtos.db            ← Banco SQLite (criado automaticamente)
├── requirements.txt
└── README.md
```

| Camada        | Arquivo              | Responsabilidade                          |
|---------------|----------------------|-------------------------------------------|
| **View**      | `templates/*.html`   | Interface do usuário                      |
| **Controller**| `app.py`             | Recebe requisições HTTP e chama o DAO     |
| **Model/DAO** | `dao/produto_dao.py` | Operações SQL (Create, Read, Update, Delete) |

---

## Como executar (modo fácil - SQLite)

Este é o modo padrão. Funciona **sem internet** e **sem configurar nada**.

### Pré-requisitos
- Python 3.10 ou superior

### Passos

```bash
# 1. Entre na pasta do projeto
cd crud-vander

# 2. Instale o Flask
pip install flask

# 3. Rode a aplicação
python app.py
```

### Acesse
```
http://localhost:5000
```

O banco SQLite (`produtos.db`) é criado automaticamente na primeira execução, já com 5 produtos de exemplo.

---

## Banco de Dados

### Padrão: SQLite
- Arquivo: `produtos.db`
- Criado automaticamente
- Ideal para o professor rodar e avaliar

### Opcional: PostgreSQL (Supabase)
1. No arquivo `dao/produto_dao.py` mude a linha:
   ```python
   USE_POSTGRES = True
   ```
2. Instale o driver:
   ```bash
   pip install psycopg2-binary
   ```
3. Execute o script `database.sql` no SQL Editor do Supabase
4. Ajuste a `DATABASE_URL` se necessário

Connection string de exemplo:
```
postgresql://postgres:CRUDVANDER3009*@db.vzpmghkiylkkknvgsfdv.supabase.co:5432/postgres
```

---

## Funcionalidades CRUD

| Operação | Rota                            | Descrição                    |
|----------|---------------------------------|------------------------------|
| Create   | `GET/POST /produto/novo`        | Cadastrar produto            |
| Read     | `GET /`                         | Listar todos                 |
| Read     | `GET /produto/<id>`             | Ver detalhes                 |
| Update   | `GET/POST /produto/<id>/editar` | Editar produto               |
| Delete   | `POST /produto/<id>/excluir`    | Excluir produto              |
| Busca    | `GET /buscar?q=termo`           | Buscar por nome/categoria    |

---

## Tecnologias

- **Backend:** Python + Flask
- **Banco:** SQLite (padrão) / PostgreSQL (opcional)
- **Acesso ao BD:** DAO (equivalente a JDBC)
- **Frontend:** HTML + Bootstrap 5
- **Padrão:** MVC

---

## Entregável

- Código-fonte completo
- Script SQL (`database.sql`)
- README com instruções de execução
- Link do repositório no GitHub
