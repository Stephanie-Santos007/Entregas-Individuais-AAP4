-- Script SQL de criação do Banco de Dados
-- Projeto: CRUD Vander's Project - Sistema de Gestão de Produtos

-- Criar tabela de produtos
CREATE TABLE IF NOT EXISTS produtos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2) NOT NULL CHECK (preco >= 0),
    quantidade INTEGER NOT NULL DEFAULT 0 CHECK (quantidade >= 0),
    categoria VARCHAR(50),
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir alguns dados de exemplo (opcional)
INSERT INTO produtos (nome, descricao, preco, quantidade, categoria) VALUES
('Notebook Dell', 'Notebook Dell Inspiron 15, 8GB RAM, 256GB SSD', 3499.90, 10, 'Eletrônicos'),
('Mouse Logitech', 'Mouse sem fio Logitech M185', 89.90, 50, 'Periféricos'),
('Teclado Mecânico', 'Teclado mecânico RGB switch blue', 299.00, 25, 'Periféricos'),
('Monitor 24"', 'Monitor LED Full HD 24 polegadas', 799.00, 15, 'Monitores'),
('Headset Gamer', 'Headset com microfone e som surround', 199.90, 30, 'Áudio')
ON CONFLICT DO NOTHING;

-- Criar índice para buscas
CREATE INDEX IF NOT EXISTS idx_produtos_nome ON produtos(nome);
CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos(categoria);

-- Comentário: Execute este script no seu banco Supabase via SQL Editor
-- ou via psql: psql "sua_connection_string" -f database.sql
