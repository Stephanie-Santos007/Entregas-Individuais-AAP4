"""
Aplicação Web CRUD - Sistema de Gestão de Produtos
Padrão MVC:
  - Model: dao/produto_dao.py (acesso ao BD)
  - View: templates/ (HTML)
  - Controller: este arquivo (rotas Flask / tratamento HTTP)
"""
from flask import Flask, render_template, request, redirect, url_for, flash
from dao.produto_dao import ProdutoDAO
import os

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "crud-vander-secret-key-2024")

# Instância do DAO
dao = ProdutoDAO()


@app.route("/")
def index():
    """READ - Lista todos os produtos (página principal)"""
    try:
        produtos = dao.read_all()
        return render_template("index.html", produtos=produtos)
    except Exception as e:
        flash(f"Erro ao carregar produtos: {str(e)}", "danger")
        return render_template("index.html", produtos=[])


@app.route("/produto/novo", methods=["GET", "POST"])
def criar_produto():
    """CREATE - Formulário e criação de novo produto"""
    if request.method == "POST":
        try:
            nome = request.form.get("nome", "").strip()
            descricao = request.form.get("descricao", "").strip()
            preco = float(request.form.get("preco", 0))
            quantidade = int(request.form.get("quantidade", 0))
            categoria = request.form.get("categoria", "").strip()

            if not nome:
                flash("Nome é obrigatório!", "warning")
                return render_template("form.html", produto=None, acao="criar")

            dao.create(nome, descricao, preco, quantidade, categoria)
            flash("Produto criado com sucesso!", "success")
            return redirect(url_for("index"))
        except Exception as e:
            flash(f"Erro ao criar produto: {str(e)}", "danger")
            return render_template("form.html", produto=None, acao="criar")

    return render_template("form.html", produto=None, acao="criar")


@app.route("/produto/<int:produto_id>")
def ver_produto(produto_id):
    """READ - Detalhes de um produto"""
    try:
        produto = dao.read_by_id(produto_id)
        if not produto:
            flash("Produto não encontrado!", "warning")
            return redirect(url_for("index"))
        return render_template("detalhe.html", produto=produto)
    except Exception as e:
        flash(f"Erro: {str(e)}", "danger")
        return redirect(url_for("index"))


@app.route("/produto/<int:produto_id>/editar", methods=["GET", "POST"])
def editar_produto(produto_id):
    """UPDATE - Formulário e atualização de produto"""
    try:
        produto = dao.read_by_id(produto_id)
        if not produto:
            flash("Produto não encontrado!", "warning")
            return redirect(url_for("index"))

        if request.method == "POST":
            nome = request.form.get("nome", "").strip()
            descricao = request.form.get("descricao", "").strip()
            preco = float(request.form.get("preco", 0))
            quantidade = int(request.form.get("quantidade", 0))
            categoria = request.form.get("categoria", "").strip()

            if not nome:
                flash("Nome é obrigatório!", "warning")
                return render_template("form.html", produto=produto, acao="editar")

            dao.update(produto_id, nome, descricao, preco, quantidade, categoria)
            flash("Produto atualizado com sucesso!", "success")
            return redirect(url_for("index"))

        return render_template("form.html", produto=produto, acao="editar")
    except Exception as e:
        flash(f"Erro: {str(e)}", "danger")
        return redirect(url_for("index"))


@app.route("/produto/<int:produto_id>/excluir", methods=["POST"])
def excluir_produto(produto_id):
    """DELETE - Remove um produto"""
    try:
        sucesso = dao.delete(produto_id)
        if sucesso:
            flash("Produto excluído com sucesso!", "success")
        else:
            flash("Produto não encontrado!", "warning")
    except Exception as e:
        flash(f"Erro ao excluir: {str(e)}", "danger")
    return redirect(url_for("index"))


@app.route("/buscar")
def buscar():
    """Busca produtos"""
    termo = request.args.get("q", "").strip()
    try:
        if termo:
            produtos = dao.search(termo)
        else:
            produtos = dao.read_all()
        return render_template("index.html", produtos=produtos, termo=termo)
    except Exception as e:
        flash(f"Erro na busca: {str(e)}", "danger")
        return render_template("index.html", produtos=[])


if __name__ == "__main__":
    # Porta 5000, acessível externamente se necessário
    app.run(host="0.0.0.0", port=5000, debug=True)
