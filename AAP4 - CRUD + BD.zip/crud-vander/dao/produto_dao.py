"""
DAO (Data Access Object) - Camada de acesso ao Banco de Dados
Padrão equivalente ao JDBC/DAO em Java

Por padrão usa SQLite (funciona offline, professor consegue rodar fácil).
Para usar PostgreSQL/Supabase: mude USE_POSTGRES = True
"""
import sqlite3
import os
from pathlib import Path

# ============================================================
# CONFIGURAÇÃO DO BANCO
# ============================================================
# False = SQLite (recomendado para entregar)
# True  = PostgreSQL (Supabase)
USE_POSTGRES = False

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:CRUDVANDER3009*@db.vzpmghkiylkkknvgsfdv.supabase.co:5432/postgres"
)

SQLITE_PATH = Path(__file__).parent.parent / "produtos.db"


class ProdutoDAO:
    """Classe DAO responsável pelas operações CRUD na tabela produtos"""

    def __init__(self):
        self.use_postgres = USE_POSTGRES
        if not self.use_postgres:
            self._init_sqlite()

    def _init_sqlite(self):
        """Cria a tabela no SQLite se não existir + dados de exemplo"""
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                descricao TEXT,
                preco REAL NOT NULL CHECK (preco >= 0),
                quantidade INTEGER NOT NULL DEFAULT 0 CHECK (quantidade >= 0),
                categoria TEXT,
                data_criacao TEXT DEFAULT CURRENT_TIMESTAMP,
                data_atualizacao TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("SELECT COUNT(*) FROM produtos")
        if cur.fetchone()[0] == 0:
            cur.executemany(
                """INSERT INTO produtos (nome, descricao, preco, quantidade, categoria)
                   VALUES (?, ?, ?, ?, ?)""",
                [
                    ("Notebook Dell", "Notebook Dell Inspiron 15, 8GB RAM, 256GB SSD", 3499.90, 10, "Eletrônicos"),
                    ("Mouse Logitech", "Mouse sem fio Logitech M185", 89.90, 50, "Periféricos"),
                    ("Teclado Mecânico", "Teclado mecânico RGB switch blue", 299.00, 25, "Periféricos"),
                    ("Monitor 24\"", "Monitor LED Full HD 24 polegadas", 799.00, 15, "Monitores"),
                    ("Headset Gamer", "Headset com microfone e som surround", 199.90, 30, "Áudio"),
                ]
            )
        conn.commit()
        conn.close()

    def _get_connection(self):
        if self.use_postgres:
            import psycopg2
            from psycopg2.extras import RealDictCursor
            conn = psycopg2.connect(DATABASE_URL, sslmode="require")
            return conn, RealDictCursor
        else:
            conn = sqlite3.connect(SQLITE_PATH)
            conn.row_factory = sqlite3.Row
            return conn, None

    def create(self, nome, descricao, preco, quantidade, categoria):
        """CREATE"""
        conn, cursor_factory = self._get_connection()
        try:
            if self.use_postgres:
                with conn.cursor(cursor_factory=cursor_factory) as cur:
                    cur.execute(
                        """INSERT INTO produtos (nome, descricao, preco, quantidade, categoria)
                           VALUES (%s, %s, %s, %s, %s)
                           RETURNING id, nome, descricao, preco, quantidade, categoria, data_criacao""",
                        (nome, descricao, preco, quantidade, categoria)
                    )
                    produto = cur.fetchone()
                    conn.commit()
                    return dict(produto) if produto else None
            else:
                cur = conn.cursor()
                cur.execute(
                    """INSERT INTO produtos (nome, descricao, preco, quantidade, categoria)
                       VALUES (?, ?, ?, ?, ?)""",
                    (nome, descricao, preco, quantidade, categoria)
                )
                conn.commit()
                return self.read_by_id(cur.lastrowid)
        finally:
            conn.close()

    def read_all(self):
        """READ - Lista todos"""
        conn, cursor_factory = self._get_connection()
        try:
            if self.use_postgres:
                with conn.cursor(cursor_factory=cursor_factory) as cur:
                    cur.execute(
                        """SELECT id, nome, descricao, preco, quantidade, categoria,
                                  data_criacao, data_atualizacao
                           FROM produtos ORDER BY id"""
                    )
                    return [dict(p) for p in cur.fetchall()]
            else:
                cur = conn.cursor()
                cur.execute(
                    """SELECT id, nome, descricao, preco, quantidade, categoria,
                              data_criacao, data_atualizacao
                       FROM produtos ORDER BY id"""
                )
                return [dict(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def read_by_id(self, produto_id):
        """READ - Por ID"""
        conn, cursor_factory = self._get_connection()
        try:
            if self.use_postgres:
                with conn.cursor(cursor_factory=cursor_factory) as cur:
                    cur.execute(
                        """SELECT id, nome, descricao, preco, quantidade, categoria,
                                  data_criacao, data_atualizacao
                           FROM produtos WHERE id = %s""",
                        (produto_id,)
                    )
                    produto = cur.fetchone()
                    return dict(produto) if produto else None
            else:
                cur = conn.cursor()
                cur.execute(
                    """SELECT id, nome, descricao, preco, quantidade, categoria,
                              data_criacao, data_atualizacao
                       FROM produtos WHERE id = ?""",
                    (produto_id,)
                )
                row = cur.fetchone()
                return dict(row) if row else None
        finally:
            conn.close()

    def update(self, produto_id, nome, descricao, preco, quantidade, categoria):
        """UPDATE"""
        conn, cursor_factory = self._get_connection()
        try:
            if self.use_postgres:
                with conn.cursor(cursor_factory=cursor_factory) as cur:
                    cur.execute(
                        """UPDATE produtos
                           SET nome = %s, descricao = %s, preco = %s, quantidade = %s,
                               categoria = %s, data_atualizacao = CURRENT_TIMESTAMP
                           WHERE id = %s
                           RETURNING id, nome, descricao, preco, quantidade, categoria, data_atualizacao""",
                        (nome, descricao, preco, quantidade, categoria, produto_id)
                    )
                    produto = cur.fetchone()
                    conn.commit()
                    return dict(produto) if produto else None
            else:
                cur = conn.cursor()
                cur.execute(
                    """UPDATE produtos
                       SET nome = ?, descricao = ?, preco = ?, quantidade = ?,
                           categoria = ?, data_atualizacao = CURRENT_TIMESTAMP
                       WHERE id = ?""",
                    (nome, descricao, preco, quantidade, categoria, produto_id)
                )
                conn.commit()
                return self.read_by_id(produto_id)
        finally:
            conn.close()

    def delete(self, produto_id):
        """DELETE"""
        conn, _ = self._get_connection()
        try:
            cur = conn.cursor()
            if self.use_postgres:
                cur.execute("DELETE FROM produtos WHERE id = %s RETURNING id", (produto_id,))
                result = cur.fetchone()
                conn.commit()
                return result is not None
            else:
                cur.execute("DELETE FROM produtos WHERE id = ?", (produto_id,))
                conn.commit()
                return cur.rowcount > 0
        finally:
            conn.close()

    def search(self, termo):
        """Busca"""
        conn, cursor_factory = self._get_connection()
        try:
            if self.use_postgres:
                with conn.cursor(cursor_factory=cursor_factory) as cur:
                    cur.execute(
                        """SELECT id, nome, descricao, preco, quantidade, categoria
                           FROM produtos
                           WHERE nome ILIKE %s OR categoria ILIKE %s OR descricao ILIKE %s
                           ORDER BY nome""",
                        (f"%{termo}%", f"%{termo}%", f"%{termo}%")
                    )
                    return [dict(p) for p in cur.fetchall()]
            else:
                cur = conn.cursor()
                cur.execute(
                    """SELECT id, nome, descricao, preco, quantidade, categoria
                       FROM produtos
                       WHERE nome LIKE ? OR categoria LIKE ? OR descricao LIKE ?
                       ORDER BY nome""",
                    (f"%{termo}%", f"%{termo}%", f"%{termo}%")
                )
                return [dict(row) for row in cur.fetchall()]
        finally:
            conn.close()
